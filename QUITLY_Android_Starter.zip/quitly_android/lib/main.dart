import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(QuitlyApp(prefs: prefs));
}

class QuitlyApp extends StatelessWidget {
  final SharedPreferences prefs;
  const QuitlyApp({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF0B1010);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'QUITLY',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF48D597),
          brightness: Brightness.dark,
          surface: const Color(0xFF151D1B),
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF151D1B),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF151D1B),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
        useMaterial3: true,
      ),
      home: HomePage(prefs: prefs),
    );
  }
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({super.key, required this.prefs});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late DateTime? quitDate;
  late int dailyCount;
  late double cigarettePrice;
  late List<String> urges;
  late List<String> slips;

  SharedPreferences get p => widget.prefs;

  @override
  void initState() {
    super.initState();
    final raw = p.getString('quitDate');
    quitDate = raw == null ? null : DateTime.tryParse(raw);
    dailyCount = p.getInt('dailyCount') ?? 10;
    cigarettePrice = p.getDouble('cigarettePrice') ?? 15;
    urges = p.getStringList('urges') ?? [];
    slips = p.getStringList('slips') ?? [];
  }

  int get days {
    if (quitDate == null) return 0;
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day)
        .difference(DateTime(quitDate!.year, quitDate!.month, quitDate!.day)).inDays
        .clamp(0, 100000);
  }

  double get saved => days * dailyCount * cigarettePrice;
  String get money(double n) => '৳${n.toStringAsFixed(n % 1 == 0 ? 0 : 2)}';

  Future<void> saveSettings(int count, double price) async {
    await p.setInt('dailyCount', count);
    await p.setDouble('cigarettePrice', price);
    setState(() { dailyCount = count; cigarettePrice = price; });
  }

  Future<void> startQuit() async {
    final d = DateTime.now();
    await p.setString('quitDate', DateTime(d.year, d.month, d.day).toIso8601String());
    setState(() => quitDate = DateTime(d.year, d.month, d.day));
  }

  Future<void> logUrge() async {
    urges.insert(0, DateTime.now().toIso8601String());
    await p.setStringList('urges', urges);
    setState(() {});
  }

  Future<void> logSlip() async {
    slips.insert(0, DateTime.now().toIso8601String());
    await p.setStringList('slips', slips);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      dashboard(),
      tracker(),
      sos(),
      settings(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('QUITLY', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 18),
            child: Center(child: Text('30-DAY JOURNEY', style: TextStyle(color: Colors.greenAccent.shade100, fontSize: 10, letterSpacing: 1))),
          )
        ],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111917),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_rounded), label: 'Tracker'),
          NavigationDestination(icon: Icon(Icons.bolt_rounded), label: 'SOS'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Settings'),
        ],
      ),
    );
  }

  Widget dashboard() {
    final progress = (days / 30).clamp(0.0, 1.0);
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(days == 0 ? 'YOUR NEW BEGINNING' : 'YOU ARE MOVING FORWARD',
          style: TextStyle(color: Colors.greenAccent.shade100, letterSpacing: 1.5, fontSize: 11, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(children: [
            SizedBox(
              width: 164, height: 164,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox.expand(child: CircularProgressIndicator(value: progress, strokeWidth: 10, backgroundColor: Colors.white10, color: const Color(0xFF48D597))),
                Column(mainAxisSize: MainAxisSize.min, children: [
                  Text('$days', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w800)),
                  const Text('SMOKE-FREE DAYS', style: TextStyle(fontSize: 9, letterSpacing: 1.2, color: Colors.white60)),
                ])
              ]),
            ),
            const SizedBox(height: 18),
            Text(days >= 30 ? '30-day milestone reached!' : '${30 - days} days to your 30-day milestone',
              style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 14),
            if (quitDate == null)
              FilledButton.icon(onPressed: startQuit, icon: const Icon(Icons.flag_rounded), label: const Text('Start my quit journey'))
            else
              OutlinedButton.icon(onPressed: () => setState(() => tab = 1), icon: const Icon(Icons.calendar_month), label: const Text('View my tracker')),
          ]),
        )),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: statCard('MONEY SAVED', money(saved), Icons.savings_rounded)),
          const SizedBox(width: 12),
          Expanded(child: statCard('CIGARETTES AVOIDED', '${days * dailyCount}', Icons.smoke_free_rounded)),
        ]),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TODAY’S REMINDER', style: TextStyle(color: Colors.white60, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 8),
            const Text('A craving is temporary. Your reason for quitting matters more.', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            TextButton.icon(onPressed: () => setState(() => tab = 2), icon: const Icon(Icons.bolt), label: const Text('I need help with a craving')),
          ]),
        )),
        const SizedBox(height: 12),
        Text('Your journey is saved on this device.', style: TextStyle(color: Colors.white.withOpacity(.45), fontSize: 12), textAlign: TextAlign.center),
      ],
    );
  }

  Widget statCard(String title, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFF48D597)),
      const SizedBox(height: 12),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(title, style: const TextStyle(fontSize: 9, color: Colors.white60, letterSpacing: .7)),
    ])),
  );

  Widget tracker() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('YOUR PROGRESS', style: TextStyle(fontSize: 11, letterSpacing: 1.5, color: Color(0xFF48D597))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('30-DAY MILESTONES', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      for (final m in [1, 3, 7, 14, 21, 30])
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(days >= m ? Icons.check_circle : Icons.circle_outlined, color: days >= m ? const Color(0xFF48D597) : Colors.white38),
          title: Text('$m ${m == 1 ? 'day' : 'days'} smoke-free'),
          subtitle: Text(days >= m ? 'Milestone reached' : '${m - days} more days to go'),
          trailing: days >= m ? const Icon(Icons.verified, color: Color(0xFF48D597)) : null,
        ),
    ]))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('RECENT CRAVINGS', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (urges.isEmpty) const Text('No cravings logged yet.', style: TextStyle(color: Colors.white60)),
      for (final item in urges.take(5)) Text('• ${DateTime.parse(item).toLocal()}'),
    ]))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('SLIP / RELAPSE LOG', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('A slip does not erase your progress. Log it honestly and restart your plan.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 8),
      if (slips.isEmpty) const Text('No slips recorded.', style: TextStyle(color: Color(0xFF48D597))),
      for (final item in slips.take(5)) Text('• ${DateTime.parse(item).toLocal()}'),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () async {
        final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
          title: const Text('Log a cigarette?'),
          content: const Text('This records a slip without judging you. Your effort still counts.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Log it'))],
        ));
        if (ok == true) await logSlip();
      }, icon: const Icon(Icons.edit_note), label: const Text('Log a slip')),
    ]))),
  ]);

  Widget sos() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('CRAVING SOS', style: TextStyle(fontSize: 11, letterSpacing: 1.5, color: Color(0xFF48D597))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.bolt_rounded, size: 38, color: Color(0xFF48D597)),
      const SizedBox(height: 12),
      const Text('Ride out this craving.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Try these steps for the next few minutes. Cravings usually rise and pass.'),
      const SizedBox(height: 18),
      for (final s in [
        '1. Put distance between you and cigarettes.',
        '2. Drink a glass of water slowly.',
        '3. Take 10 slow breaths.',
        '4. Walk, stretch, or keep your hands busy.',
        '5. Message someone who supports your quit attempt.',
      ]) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(s, style: const TextStyle(height: 1.4))),
      FilledButton.icon(onPressed: logUrge, icon: const Icon(Icons.check), label: const Text('I handled a craving')),
    ]))),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: const Text('If withdrawal feels difficult, a pharmacist or healthcare professional can help you choose evidence-based support such as nicotine replacement therapy.')),
    ),
  ]);

  Widget settings() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('PERSONAL SETTINGS', style: TextStyle(fontSize: 11, letterSpacing: 1.5, color: Color(0xFF48D597))),
    const SizedBox(height: 12),
    SettingsForm(initialCount: dailyCount, initialPrice: cigarettePrice, onSave: saveSettings),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('DATA & PRIVACY', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Your tracker data is stored locally on this device. It is not synced to an account or cloud backup in this starter version.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: () async {
        final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
          title: const Text('Reset quit date?'),
          content: const Text('This sets today as your new quit date. Your craving and slip logs remain.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Reset date'))],
        ));
        if (ok == true) await startQuit();
      }, icon: const Icon(Icons.restart_alt), label: const Text('Restart quit date')),
    ]))),
  ]);
}

class SettingsForm extends StatefulWidget {
  final int initialCount;
  final double initialPrice;
  final Future<void> Function(int, double) onSave;
  const SettingsForm({super.key, required this.initialCount, required this.initialPrice, required this.onSave});
  @override
  State<SettingsForm> createState() => _SettingsFormState();
}
class _SettingsFormState extends State<SettingsForm> {
  late final count = TextEditingController(text: widget.initialCount.toString());
  late final price = TextEditingController(text: widget.initialPrice.toString());
  @override
  void dispose() { count.dispose(); price.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('SMOKING BASELINE', style: TextStyle(fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    TextField(controller: count, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cigarettes per day')),
    const SizedBox(height: 12),
    TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Price per cigarette (BDT)')),
    const SizedBox(height: 14),
    FilledButton(onPressed: () {
      final c = int.tryParse(count.text.trim());
      final v = double.tryParse(price.text.trim());
      if (c == null || v == null || c < 0 || v < 0) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter valid non-negative numbers.')));
        return;
      }
      widget.onSave(c, v);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved.')));
    }, child: const Text('Save settings')),
  ])));
}
