# QUITLY — Android starter app

A dark-themed Flutter smoking cessation tracker.

## Included
- Smoke-free day counter and 30-day milestones
- Estimated money saved and cigarettes avoided
- Craving SOS checklist and craving log
- Slip/relapse log (without judgement)
- Daily cigarette count and per-cigarette cost settings
- Local on-device storage using SharedPreferences

## Build an Android APK
1. Install Flutter SDK and Android Studio.
2. Extract this project.
3. Open a terminal in the `quitly_android` folder.
4. Run:
   - `flutter pub get`
   - `flutter run` (test on a connected Android phone/emulator)
   - `flutter build apk --release`
5. APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Notes
- This is a starter version, not a medical device.
- Data is stored locally on the device. Uninstalling the app or clearing app data may erase it.
- Cloud sync, encrypted export/restore, notifications, Bengali localization, and Play Store signing are not included yet.
- Money saved is an estimate based on the daily cigarette baseline and configured price per cigarette.
